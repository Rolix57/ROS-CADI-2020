#!/usr/bin/env python
import rospy
from std_msgs.msg import UInt16
from rosserial_arduino.msg import Adc
import numpy as np

class PotServo:
    def __init__(self):
        self.angle = 0.0

    def callback(self, data):
        self.angle = data.adc0 * 180.0 / 1023.0
    
    def host(self):
        rospy.init_node('potservo_host', anonymous=True)
        rospy.Subscriber('adc', Adc, self.callback)
        pub = rospy.Publisher('servo', UInt16, queue_size=10)
        rate = rospy.Rate(20)

        while not rospy.is_shutdown():
            pub.publish(int(self.angle))
            print(self.angle)
            rate.sleep()

if __name__ == '__main__':
    try:
        my_potservo = PotServo()
        my_potservo.host()
    except rospy.ROSInterruptException:
        pass